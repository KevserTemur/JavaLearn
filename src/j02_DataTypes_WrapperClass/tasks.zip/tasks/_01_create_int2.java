package j02_DataTypes_WrapperClass.tasks;

public class _01_create_int2 {

    public static void main(String[] args) {

      /*    Değeri 100 olan bir int oluştur.
            Ve bu int 'i yazdır.      */


        //Kodu aşağıya yazınız.

        int a = 100;
        System.out.println(a);


    }

}


