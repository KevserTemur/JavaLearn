package j02_DataTypes_WrapperClass.tasks;

public class _02_create_int1 {

    public static void main(String[] args) {

    /*    Değeri 15 olan bir int oluşturun.
           Int'i yazdırın  */

        // Kodu aşağıya yazınız.


        int x=15;
        System.out.println(x);
    }
}
