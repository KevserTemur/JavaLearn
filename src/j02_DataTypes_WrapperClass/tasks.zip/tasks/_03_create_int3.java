package j02_DataTypes_WrapperClass.tasks;

public class _03_create_int3 {

    public static void main(String[] args) {

    /*    Değeri 120 olan bir int oluşturın.
          Int'i yazdırın.  */

        //Kodu aşağıya yazınız.

        int x=120;
        System.out.println(x);

    }
}
