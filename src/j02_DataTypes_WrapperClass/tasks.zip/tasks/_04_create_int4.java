package j02_DataTypes_WrapperClass.tasks;

public class _04_create_int4 {

    public static void main(String[] args) {

     /*   Değeri -6500 olan bir int oluşturunuz.
          Int'i yazdırınız. */

        //Kodu aşağıya yazınız.
    int x=-6500;
        System.out.println(x);

    }
}
