package j02_DataTypes_WrapperClass.tasks;

public class _05_create_boolean1 {

    public static void main(String[] args) {


    /*    Değeri 'true' olan bir boolean oluşturunuz.
          Boolean'ı yazdırınız. */

        //Kodu aşağıya yazınız.
boolean ogrenciMi=true;
        System.out.println(ogrenciMi);

    }
}
