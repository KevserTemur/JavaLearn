package j02_DataTypes_WrapperClass.tasks;

public class _06_create_boolean2 {

    public static void main(String[] args) {

    /*    Değer i 'false' olan bir boolean oluşturunuz.
          Boolean'ı yazdırınız. */

        //Kodu aşağıya yazınız.

boolean calisiyorMu=false;
        System.out.println(calisiyorMu);
    }
}
