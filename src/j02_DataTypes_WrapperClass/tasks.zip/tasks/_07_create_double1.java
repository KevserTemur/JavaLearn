package j02_DataTypes_WrapperClass.tasks;

public class _07_create_double1 {

    public static void main(String[] args) {

    /*    Değeri 120 olan bir double oluşturunuz.
          Double' ı yazdırınız.  */

        //Kodu aşağıya yazınız.

double oran=120d;
        System.out.println(oran);
    }
}
