package j02_DataTypes_WrapperClass.tasks;

public class _09_create_double3 {

    public static void main(String[] args) {

    /*    Değeri 10.01 olan bir double oluşturunuz.
          Double'ı yazdırınız.   */

        //Kodu aşağıya yazınız.

double oran=10.01;
        System.out.println(oran);

    }


}
