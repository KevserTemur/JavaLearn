package j02_DataTypes_WrapperClass.tasks;

public class _10_create_double4 {

    public static void main(String[] args) {

    /*    Değeri 550.24  olan bir double oluşturunuz.
          Double'ı yazdırınız.  */

        //Kodu aşağıya yazınız.
double oran=550.24d;
        System.out.println(oran);



    }


}
