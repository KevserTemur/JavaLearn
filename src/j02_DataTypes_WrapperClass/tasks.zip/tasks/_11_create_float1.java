package j02_DataTypes_WrapperClass.tasks;

public class _11_create_float1 {

    public static void main(String[] args) {

    /*    Değeri 121.005f olan bir float oluşturunuz.
          Float'ı yazdırınız.   */

        //Kodu aşağıya yazınız.

float oran=121.005f;
        System.out.println(oran);

    }
}
