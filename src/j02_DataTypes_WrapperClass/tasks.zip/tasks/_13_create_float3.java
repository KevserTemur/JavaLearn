package j02_DataTypes_WrapperClass.tasks;

public class _13_create_float3 {

    public static void main(String[] args) {

    /*    Değeri 3.55f olan bir float oluşturunuz.
        Float'ı yazdırınız.   */

        //Kodu aşağıya yazınız.


float oran=3.55f;
        System.out.println(oran);

    }
}
