package j02_DataTypes_WrapperClass.tasks;

public class _19_create_char3 {

    public static void main(String[] args) {

    /*    & olan bir char oluşturun.
          Bu char'ı yazdırın.   */

        //Kodu aşağıya yazınız.

        char harf='&';
        System.out.println(harf);

    }
}
