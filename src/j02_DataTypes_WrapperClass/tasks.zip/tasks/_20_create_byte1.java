package j02_DataTypes_WrapperClass.tasks;

public class _20_create_byte1 {

    public static void main(String[] args) {

    /*    Değeri 5 olan bir byte oluşturun.
          Bu byte'ı yazdırın.  */

        //Kodu aşağıya yazınız.

byte deger=5;
        System.out.println(deger);

    }
}
