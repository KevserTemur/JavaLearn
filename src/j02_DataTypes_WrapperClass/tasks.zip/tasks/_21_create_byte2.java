package j02_DataTypes_WrapperClass.tasks;

public class _21_create_byte2 {

    public static void main(String[] args) {

    /*    Değeri -4 olan bir byte oluşturun.
          Bu byte'ı yazdırın.   */

        //Kodu aşağıya yazınız.

        byte deger=-4;
        System.out.println(deger);

    }
}
